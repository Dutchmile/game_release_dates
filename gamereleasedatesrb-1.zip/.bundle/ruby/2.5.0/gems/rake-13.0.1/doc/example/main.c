#include <stdio.h>

extern void a();
extern void b();

int main ()
{
    a();
    b();
    return 0;
}
