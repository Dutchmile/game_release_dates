#ifndef NOKOGIRI_HTML_SAX_PARSER_CONTEXT
#define NOKOGIRI_HTML_SAX_PARSER_CONTEXT

#include <nokogiri.h>

extern VALUE cNokogiriHtmlSaxParserContext;

void init_html_sax_parser_context();

#endif

