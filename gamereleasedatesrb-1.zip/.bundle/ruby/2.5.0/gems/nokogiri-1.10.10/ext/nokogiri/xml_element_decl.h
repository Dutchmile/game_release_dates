#ifndef NOKOGIRI_XML_ELEMENT_DECL
#define NOKOGIRI_XML_ELEMENT_DECL

#include <nokogiri.h>

void init_xml_element_decl();

extern VALUE cNokogiriXmlElementDecl;
#endif
