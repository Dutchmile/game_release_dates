#ifndef NOKOGIRI_HTML_ELEMENT_DESCRIPTION
#define NOKOGIRI_HTML_ELEMENT_DESCRIPTION

#include <nokogiri.h>

void init_html_element_description();

extern VALUE cNokogiriHtmlElementDescription ;

#endif
