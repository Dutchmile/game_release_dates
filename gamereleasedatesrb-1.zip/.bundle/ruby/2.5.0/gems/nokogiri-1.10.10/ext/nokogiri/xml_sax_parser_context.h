#ifndef NOKOGIRI_XML_SAX_PARSER_CONTEXT
#define NOKOGIRI_XML_SAX_PARSER_CONTEXT

#include <nokogiri.h>

extern VALUE cNokogiriXmlSaxParserContext;

void init_xml_sax_parser_context();

#endif
