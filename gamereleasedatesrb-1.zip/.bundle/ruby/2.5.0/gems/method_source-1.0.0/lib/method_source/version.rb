module MethodSource
  VERSION = '1.0.0'.freeze
end
