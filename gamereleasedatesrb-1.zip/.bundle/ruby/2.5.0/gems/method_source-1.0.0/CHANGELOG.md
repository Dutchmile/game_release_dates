method_source changelog
=======================

### master

### [v1.0.0][v1.0.0] (March 19, 2020)

* Added Ruby 2.7 support

[v1.0.0]: https://github.com/banister/method_source/releases/tag/v1.0.0
