class MiniPortile
  VERSION = "2.4.0"
end
