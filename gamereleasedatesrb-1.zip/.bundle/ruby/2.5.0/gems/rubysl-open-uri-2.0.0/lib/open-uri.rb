require "rubysl/open-uri"
