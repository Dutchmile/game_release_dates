require "rubysl/open-uri/open-uri"
require "rubysl/open-uri/version"
